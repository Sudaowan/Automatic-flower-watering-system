const app = getApp()

Page({
  data: {
    uid: 'bb836c32bb644aa81ea37aa18794cfda',
    topic: "1",
    topic_data: "wd",
    device_status: "离线", //默认离线
    powerstatus:"已关闭",   //默认关闭
    state:"未开启",
    humidity:"----"//自定义变量，湿度
  },
  Aclick: function() {

    //当点击打开按钮，更新开关状态为打开
  var that = this
  that.setData({
    powerstatus:"已打开",
    state:"仙人掌属"
  })
      //控制接口
      wx.request({
        url: 'https://api.bemfa.com/api/device/v1/data/1/', //api接口，详见接入文档
        method:"POST",
        data: {  //请求字段，详见巴法云接入文档，http接口
          uid: that.data.uid,
          topic: that.data.topic,
          msg:"HPL"   //发送消息为HPL(虎皮兰)的消息
        },
        header: {
          'content-type': "application/x-www-form-urlencoded"
        },
        success (res) {
          console.log(res.data)
          wx.showToast({
            title:'打开成功',
            icon:'success',
            duration:1000
          })
        }
      })
  },
  //”打开“按钮处理函数函数
  openclick: function() {

      //当点击打开按钮，更新开关状态为打开
    var that = this
    that.setData({
      powerstatus:"已打开",
      state:"麒麟叶属"
    })

        //控制接口
        wx.request({
          url: 'https://api.bemfa.com/api/device/v1/data/1/', //api接口，详见接入文档
          method:"POST",
          data: {  //请求字段，详见巴法云接入文档，http接口
            uid: that.data.uid,
            topic: that.data.topic,
            msg:"LL"   //发送消息为LL(麒麟叶属)的消息
          },
          header: {
            'content-type': "application/x-www-form-urlencoded"
          },
          success (res) {
            console.log(res.data)
            wx.showToast({
              title:'打开成功',
              icon:'success',
              duration:1000
            })
          }
        })
  },
   //”关闭“按钮处理函数函数
   closeclick: function() {

    //当点击关闭按钮，更新开关状态为关闭
    var that = this
    that.setData({
      powerstatus:"已关闭",
      state:"未开启"
    })

     //控制接口
     wx.request({
      url: 'https://api.bemfa.com/api/device/v1/data/1/', //api接口，详见接入文档
      method:"POST",
      data: {
        uid: that.data.uid,
        topic: that.data.topic,
        msg:"off"
      },
      header: {
        'content-type': "application/x-www-form-urlencoded"
      },
      success (res) {
        console.log(res.data)
        wx.showToast({
          title:'关闭成功',
          icon:'success',
          duration:1000
        })
      }
    })
  },
  onLoad: function () {
    var that = this

    //请求设备状态
    //设备断开不会立即显示离线，由于网络情况的复杂性，离线1分钟左右才判断真离线
    wx.request({
      url: 'https://api.bemfa.com/api/device/v1/status/', //状态api接口，详见巴法云接入文档
      data: {
        uid: that.data.uid,
        topic: that.data.topic,
      },
      header: {
        'content-type': "application/x-www-form-urlencoded"
      },
      success (res) {
        console.log(res.data)
        if(res.data.status === "online"){
          that.setData({
            device_status:"在线"
          })
        }else{
          that.setData({
            device_status:"离线"
          })
        }
        console.log(that.data.device_status)
      }
    })

          //请求询问设备开关/状态
          wx.request({
            url: 'https://api.bemfa.com/api/device/v1/data/1/', //get接口，详见巴法云接入文档
            data: {
              uid: that.data.uid,
              topic: that.data.topic,
            },
            header: {
              'content-type': "application/x-www-form-urlencoded"
            },
            success (res) {
              console.log(res.data)
              if(res.data.msg.indexOf("#") != -1){//如果数据里包含#号，表示获取的是传感器值，因为单片机上传数据的时候用#号进行了包裹
                //如果有#号就进行字符串分割
                var all_data_arr = res.data.msg.split("#"); //分割数据，并把分割后的数据放到数组里。
                console.log(all_data_arr)//打印数组
                that.setData({ //数据赋值给变量
                  humidity:all_data_arr[1], //赋值湿度
                })
              }

          },
            success (res) {
              console.log(res.data)
              if(res.data.msg === "on"){
                that.setData({
                  powerstatus:"已打开"
                })
              }
              console.log(that.data.powerstatus)
            }
          })


    //设置定时器，每五秒请求一下设备状态
    setInterval(function () {
      console.log("定时请求设备状态,默认五秒");
      wx.request({
        url: 'https://api.bemfa.com/api/device/v1/status/',  //get 设备状态接口，详见巴法云接入文档
        data: {
          uid: that.data.uid,
          topic: that.data.topic,
        },
        header: {
          'content-type': "application/x-www-form-urlencoded"
        },
        success (res) {
          console.log(res.data)
          if(res.data.status === "online"){
            that.setData({
              device_status:"在线"
            })
          }else{
            that.setData({
              device_status:"离线"
            })
          }
          console.log(that.data.device_status)
        }
      })

      //请求询问设备开关/状态
      wx.request({
        url: 'https://api.bemfa.com/api/device/v1/data/1/', //get接口，详见巴法云接入文档
        data: {
          uid: that.data.uid,
          topic: that.data.topic,
        },
        header: {
          'content-type': "application/x-www-form-urlencoded"
        },
        success (res) {
          console.log(res.data)
          if(res.data.msg === "on"){
            that.setData({
              powerstatus:"已打开"
            })
          }
          console.log(that.data.powerstatus)
        }
      })
      console.log("请求获取各种传感器值,默认2秒");
      ////请求获取各种传感器值
      wx.request({
        url: 'https://api.bemfa.com/api/device/v1/data/1/', //get接口，详见巴法云接入文档
        data: {
          uid: that.data.uid,
          topic: that.data.topic_data,
        },
        header: {
          'content-type': "application/x-www-form-urlencoded"
        },
        success (res) {
            console.log(res.data)
            if(res.data.msg.indexOf("#") != -1){//如果数据里包含#号，表示获取的是传感器值，因为单片机上传数据的时候用#号进行了包裹
              //如果有#号就进行字符串分割
              var all_data_arr = res.data.msg.split("#"); //分割数据，并把分割后的数据放到数组里。
              console.log(all_data_arr)//打印数组
              that.setData({ //数据赋值给变量
                humidity:all_data_arr[1], //赋值湿度
              })
            }
        }
      })

    }, 5000)
    
  }
})

